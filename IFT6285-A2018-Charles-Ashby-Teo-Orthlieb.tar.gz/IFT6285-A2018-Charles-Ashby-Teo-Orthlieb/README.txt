Pour faire tourner le programme, il faut lancer model_eval.py avec python 3, on peut changer les contextes avec la variable contexts du main,
changer la langue avec lang, et le modèle avec mclass.